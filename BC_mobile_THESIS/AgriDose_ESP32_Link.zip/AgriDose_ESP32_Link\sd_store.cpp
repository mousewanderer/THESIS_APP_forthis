#include "sd_store.h"
#include "config.h"
#include <SPI.h>
#include <SD.h>

static SPIClass sdSPI(VSPI);
static SemaphoreHandle_t sdMutex = nullptr;
static bool sdOk = false;

static bool sdLock()   { return sdMutex && xSemaphoreTake(sdMutex, pdMS_TO_TICKS(SD_WAIT_MS)) == pdTRUE; }
static void sdUnlock() { xSemaphoreGive(sdMutex); }

bool sdBegin() {
  sdMutex = xSemaphoreCreateMutex();
  sdSPI.begin(SD_SCK_PIN, SD_MISO_PIN, SD_MOSI_PIN, SD_CS_PIN);
  sdOk = SD.begin(SD_CS_PIN, sdSPI);
  if (sdOk) {
    Serial.println("SD card OK");
  } else {
    Serial.println("SD card not found -- dose log and crop records are off.");
    Serial.println("  If the wiring is right, try swapping SD_MISO_PIN / SD_MOSI_PIN.");
  }
  return sdOk;
}

bool sdReady() { return sdOk; }

bool sdAppendLine(const char* path, const char* line, const char* header) {
  if (!sdOk) return false;
  if (!sdLock()) { Serial.println("SD busy -- line not written"); return false; }
  if (header && !SD.exists(path)) {
    File h = SD.open(path, FILE_WRITE);
    if (h) { h.println(header); h.close(); }
  }
  bool ok = false;
  File f = SD.open(path, FILE_APPEND);
  if (f) {
    ok = f.println(line) > 0;
    f.close();
  }
  sdUnlock();
  if (!ok) {
    Serial.printf("SD write to %s failed -- marking the SD card offline\n", path);
    sdOk = false;
  }
  return ok;
}

int sdReadAt(const char* path, uint32_t offset, uint8_t* buf, size_t len) {
  if (!sdOk || !sdLock()) return -1;
  int n = -1;
  File f = SD.open(path, FILE_READ);
  if (f) {
    n = f.seek(offset) ? (int)f.read(buf, len) : 0;
    f.close();
  }
  sdUnlock();
  return n;
}

int32_t sdFileSize(const char* path) {
  if (!sdOk || !sdLock()) return -1;
  int32_t size = -1;
  File f = SD.open(path, FILE_READ);
  if (f) {
    size = (int32_t)f.size();
    f.close();
  }
  sdUnlock();
  return size;
}

bool sdMakeDir(const char* path) {
  if (!sdOk || !sdLock()) return false;
  bool ok = SD.exists(path) || SD.mkdir(path);
  sdUnlock();
  return ok;
}

bool sdCreateIfMissing(const char* path, const char* header) {
  if (!sdOk || !sdLock()) return false;
  bool ok = SD.exists(path);
  if (!ok) {
    File f = SD.open(path, FILE_WRITE);
    if (f) { ok = f.println(header) > 0; f.close(); }
  }
  sdUnlock();
  return ok;
}

uint8_t csvSplit(char* line, char* fields[], uint8_t maxFields) {
  uint8_t n = 0;
  char* p = line;
  while (n < maxFields) {
    fields[n++] = p;
    char* comma = strchr(p, ',');
    if (comma == nullptr) break;
    *comma = 0;
    p = comma + 1;
  }
  return n;
}

bool sdForEachLine(const char* path, const std::function<void(char* line)>& onLine) {
  char chunk[1024];
  char line[SD_LINE_MAX + 1];
  size_t lineLen = 0;
  bool tooLong = false;
  uint32_t pos = 0;

  for (;;) {
    int n = sdReadAt(path, pos, (uint8_t*)chunk, sizeof(chunk));
    if (n < 0) return false;                     // missing file, or card busy / gone
    if (n == 0) break;                           // end of file
    pos += n;
    for (int i = 0; i < n; i++) {
      char c = chunk[i];
      if (c == '\n') {
        line[lineLen] = 0;
        if (lineLen > 0 && !tooLong) onLine(line);
        lineLen = 0;
        tooLong = false;
      } else if (c == '\r') {
        // Windows line ending: ignore
      } else if (lineLen < SD_LINE_MAX) {
        line[lineLen++] = c;
      } else {
        tooLong = true;
      }
    }
  }
  if (lineLen > 0 && !tooLong) {                 // last line without a newline
    line[lineLen] = 0;
    onLine(line);
  }
  return true;
}
