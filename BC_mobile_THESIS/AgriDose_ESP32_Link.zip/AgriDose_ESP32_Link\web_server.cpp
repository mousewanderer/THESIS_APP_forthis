#include "web_server.h"
#include "config.h"
#include "live_state.h"
#include "sd_store.h"
#include "dose_log.h"
#include "crop_records.h"
#include "json_util.h"
#include "web_assets.h"
#include <new>
#include <WiFi.h>
#include <DNSServer.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>

static_assert(sizeof(AP_PASSWORD) - 1 >= 8, "AP_PASSWORD in config.h needs at least 8 characters");

#define STATUS_JSON_MAX 448
#define DOSES_LIMIT_MAX 200

static AsyncWebServer server(80);
static AsyncWebSocket ws("/ws");
#if CAPTIVE_PORTAL
static DNSServer dns;
#endif

// ------------------------------------------------------- live status --
// The same JSON goes to /api/status and to every WebSocket client.
static size_t buildStatusJson(const LiveState& s, char* out, size_t size) {
  bool online = liveMegaOnline(s);
  unsigned long age = s.everHeard ? millis() - s.lastFrameMs : 0;
  int n = snprintf(out, size,
      "{\"online\":%s,\"weight_dg\":%ld,\"flag\":\"%c\",\"last_frame_ms\":%lu,"
      "\"done_count\":%lu,\"dose_count\":%lu,\"sd_ok\":%s,\"fake_mega\":%s,"
      "\"boot\":%lu,\"uptime_s\":%lu,\"heap_free\":%lu,\"heap_min\":%lu,\"clients\":%u",
      online ? "true" : "false", (long)s.weightDg, s.flag, age,
      (unsigned long)s.doneCount, (unsigned long)doseLogCount(), sdReady() ? "true" : "false",
      FAKE_MEGA ? "true" : "false", (unsigned long)doseLogBoot(), (unsigned long)(millis() / 1000),
      (unsigned long)ESP.getFreeHeap(), (unsigned long)ESP.getMinFreeHeap(), (unsigned)ws.count());
  if (s.lastDone.valid) {
    n += snprintf(out + n, size - n, ",\"last\":{\"seq\":%u,\"recipe\":\"%c\",\"target_dg\":%ld,\"actual_dg\":%ld}",
                  s.lastDone.seq, s.lastDone.recipe, (long)s.lastDone.targetDg, (long)s.lastDone.actualDg);
  }
  n += snprintf(out + n, size - n, "}");
  return n;
}

// ---------------------------------------------------------- helpers --
static void sendJsonError(AsyncWebServerRequest* r, int code, const String& message) {
  AsyncResponseStream* res = r->beginResponseStream("application/json");
  res->setCode(code);
  res->print("{\"ok\":false,\"error\":");
  jsonString(*res, message.c_str());
  res->print('}');
  r->send(res);
}

static long queryLong(AsyncWebServerRequest* r, const char* name, long fallback) {
  const AsyncWebParameter* p = r->getParam(name);
  return p ? p->value().toInt() : fallback;
}

// Reads one field from a submitted form ("" if it is missing).
static FieldGetter formFields(AsyncWebServerRequest* r) {
  return [r](const char* name) -> String {
    const AsyncWebParameter* p = r->getParam(name, true);   // true = from the form body
    return p ? p->value() : String();
  };
}

static void serveAsset(AsyncWebServerRequest* r, const WebAsset& a) {
  AsyncWebServerResponse* res = r->beginResponse(200, a.type, a.data, a.len);
  if (a.gzipped) res->addHeader("Content-Encoding", "gzip");
  res->addHeader("Cache-Control", a.gzipped ? "no-cache" : "max-age=86400");
  r->send(res);
}

// ------------------------------------------------------------- API --
static void handleDoses(AsyncWebServerRequest* r) {
  long limit = constrain(queryLong(r, "limit", 20), 1L, (long)DOSES_LIMIT_MAX);
  DoseRow* rows = new (std::nothrow) DoseRow[limit];
  if (rows == nullptr) { sendJsonError(r, 503, "The ESP32 is out of memory, try again"); return; }
  int n = doseLogNewest(rows, (int)limit);
  if (n < 0) { delete[] rows; sendJsonError(r, 503, "Could not read the SD card"); return; }

  AsyncResponseStream* res = r->beginResponseStream("application/json");
  res->printf("{\"total\":%lu,\"items\":[", (unsigned long)doseLogCount());
  for (int i = 0; i < n; i++) {
    const DoseRow& d = rows[i];
    res->printf("%s{\"no\":%lu,\"boot\":%lu,\"uptime_s\":%lu,\"seq\":%u,\"recipe\":\"%c\",\"target_dg\":%ld,\"actual_dg\":%ld}",
                i ? "," : "", (unsigned long)d.no, (unsigned long)d.boot, (unsigned long)d.uptimeS,
                d.seq, d.recipe, (long)d.targetDg, (long)d.actualDg);
  }
  res->print("]}");
  delete[] rows;
  r->send(res);
}

// The size is taken once, at the start. Rows logged during the download
// are not included, so the file never arrives cut in the middle of a row.
// Each piece is read with its own short turn on the SD mutex.
static void handleDosesCsv(AsyncWebServerRequest* r) {
  int32_t size = sdFileSize(DOSE_LOG_PATH);
  if (size < 0) { sendJsonError(r, 503, "Could not read the SD card"); return; }
  AsyncWebServerResponse* res = r->beginResponse("text/csv", (size_t)size,
      [size](uint8_t* buf, size_t maxLen, size_t index) -> size_t {
        if (index >= (size_t)size) return 0;
        size_t want = (size_t)size - index;
        if (want > maxLen) want = maxLen;
        if (want > 1024) want = 1024;
        int n = sdReadAt(DOSE_LOG_PATH, index, buf, want);
        if (n < 0) return sdReady() ? RESPONSE_TRY_AGAIN : 0;   // busy: the server asks again shortly
        return (size_t)n;
      });
  res->addHeader("Content-Disposition", "attachment; filename=\"agridose_dose_log.csv\"");
  r->send(res);
}

static void addRecordRoutes(RecordType t) {
  String path = String("/api/records/") + cropTypeName(t);

  server.on(path.c_str(), HTTP_GET, [t](AsyncWebServerRequest* r) {
    long userId = queryLong(r, "user_id", 0);
    if (userId <= 0) { sendJsonError(r, 400, "user_id is missing"); return; }
    AsyncResponseStream* res = r->beginResponseStream("application/json");
    String error;
    if (!cropWriteRecordsJson(t, userId, (int)queryLong(r, "limit", 3), *res, error)) {
      delete res;
      sendJsonError(r, 503, error);
      return;
    }
    r->send(res);
  });

  server.on(path.c_str(), HTTP_POST, [t](AsyncWebServerRequest* r) {
    String error;
    if (!cropAddRecord(t, formFields(r), error)) { sendJsonError(r, 400, error); return; }
    r->send(200, "application/json", "{\"ok\":true}");
  });
}

// --------------------------------------------------------- WebSocket --
static void onWsEvent(AsyncWebSocket* s, AsyncWebSocketClient* c, AwsEventType type, void*, uint8_t*, size_t) {
  if (type == WS_EVT_CONNECT) {
    char buf[STATUS_JSON_MAX];
    buildStatusJson(liveGet(), buf, sizeof(buf));
    c->text(buf);                    // a new phone gets the current state at once
    Serial.printf("Dashboard: phone connected (%u open)\n", (unsigned)s->count());
  } else if (type == WS_EVT_DISCONNECT) {
    Serial.println("Dashboard: phone disconnected");
  }
  // WS_EVT_DATA: anything a phone sends here is ignored on purpose.
}

// What counts as "changed" for the live feed (timers and heap numbers do not).
struct LiveKey {
  bool online, sdOk;
  int32_t weightDg;
  char flag;
  uint32_t doneCount, doseCount;
  bool operator!=(const LiveKey& o) const {
    return online != o.online || sdOk != o.sdOk || weightDg != o.weightDg || flag != o.flag ||
           doneCount != o.doneCount || doseCount != o.doseCount;
  }
};

void webLoop() {
  static uint32_t lastCheckAt = 0, lastSentAt = 0, lastCleanupAt = 0;
  static LiveKey sent = {};
  uint32_t now = millis();

  if (now - lastCleanupAt >= 1000) {
    lastCleanupAt = now;
    ws.cleanupClients(WS_MAX_CLIENTS);   // drops dead connections and any over the limit
  }
  if (now - lastCheckAt < WS_PERIOD_MS) return;
  lastCheckAt = now;
  if (ws.count() == 0) return;

  LiveState s = liveGet();
  LiveKey key = {liveMegaOnline(s), sdReady(), s.weightDg, s.flag, s.doneCount, doseLogCount()};
  if (!(key != sent) && now - lastSentAt < WS_HEARTBEAT_MS) return;   // no change, heartbeat not due

  char buf[STATUS_JSON_MAX];
  buildStatusJson(s, buf, sizeof(buf));
  ws.textAll(buf);
  sent = key;
  lastSentAt = now;
}

// ----------------------------------------------------------- start --
void webBegin() {
  IPAddress ip(AP_IP);
  WiFi.persistent(false);
  WiFi.mode(WIFI_AP);
  WiFi.softAPConfig(ip, ip, IPAddress(255, 255, 255, 0));
  if (WiFi.softAP(AP_SSID, AP_PASSWORD, AP_CHANNEL, 0, AP_MAX_PHONES)) {
    Serial.printf("Wi-Fi access point \"%s\" is on. Dashboard: http://%s/\n", AP_SSID, AP_IP_TEXT);
  } else {
    Serial.println("Wi-Fi access point FAILED to start");
  }

#if CAPTIVE_PORTAL
  dns.start(53, "*", ip);            // every name a phone looks up points to the ESP32
#endif

  ws.onEvent(onWsEvent);
  server.addHandler(&ws);

  // Page files, from web_assets.h (made by tools/make_web_assets.py)
  for (size_t i = 0; i < WEB_ASSET_COUNT; i++) {
    const WebAsset* a = &WEB_ASSETS[i];
    server.on(a->path, HTTP_GET, [a](AsyncWebServerRequest* r) { serveAsset(r, *a); });
  }

  server.on("/api/status", HTTP_GET, [](AsyncWebServerRequest* r) {
    char buf[STATUS_JSON_MAX];
    buildStatusJson(liveGet(), buf, sizeof(buf));
    r->send(200, "application/json", buf);
  });
  server.on("/api/doses", HTTP_GET, handleDoses);
  server.on("/api/doses.csv", HTTP_GET, handleDosesCsv);

  server.on("/api/record-types", HTTP_GET, [](AsyncWebServerRequest* r) {
    AsyncResponseStream* res = r->beginResponseStream("application/json");
    cropWriteTypesJson(*res);
    r->send(res);
  });
  server.on("/api/users", HTTP_GET, [](AsyncWebServerRequest* r) {
    AsyncResponseStream* res = r->beginResponseStream("application/json");
    String error;
    if (!cropWriteUsersJson(*res, error)) { delete res; sendJsonError(r, 503, error); return; }
    r->send(res);
  });
  server.on("/api/users", HTTP_POST, [](AsyncWebServerRequest* r) {
    String error;
    if (!cropAddUser(formFields(r), error)) { sendJsonError(r, 400, error); return; }
    r->send(200, "application/json", "{\"ok\":true}");
  });
  for (uint8_t t = 0; t < REC_TYPE_COUNT; t++) addRecordRoutes((RecordType)t);

#if CAPTIVE_PORTAL
  // Phones open these addresses to test for internet. Sending them to the
  // dashboard makes the phone show it right after joining the Wi-Fi.
  static const char* const PROBES[] = {"/generate_204", "/gen_204", "/hotspot-detect.html",
                                       "/library/test/success.html", "/connecttest.txt", "/ncsi.txt",
                                       "/canonical.html", "/success.txt"};
  for (const char* p : PROBES) {
    server.on(p, HTTP_ANY, [](AsyncWebServerRequest* r) { r->redirect("http://" AP_IP_TEXT "/"); });
  }
#endif
  server.onNotFound([](AsyncWebServerRequest* r) {
#if CAPTIVE_PORTAL
    if (r->host() != AP_IP_TEXT) { r->redirect("http://" AP_IP_TEXT "/"); return; }   // another website name
#endif
    sendJsonError(r, 404, "Not found");
  });

  server.begin();
}
