// =====================================================================
//  crop_records -- farmers (users) and their crop records on the microSD.
//  Thesis objective 2.3: crop status logging per user.
//
//  Files in /crop/ (one row per record, the first column is the user ID):
//    users.csv      user_id,name
//    soil.csv       user_id,plot,date_tested,soil_ph,soil_moisture_pct
//    plantings.csv  user_id,plot,crop,variety,date_planted,used_agridose,dose_numbers
//    growth.csv     user_id,plot,date_observed,stage,days_after_planting,height_cm,leaf_count,notes
//
//  The fields follow agridose-v2/docs/05-phone-app.md (the Records tab).
//  Every value is checked here on the ESP32 (crop_validate.h) before it is
//  written, so a bad phone or a hand-made request cannot put rubbish in
//  the files. Nothing in this file talks to the Mega.
// =====================================================================
#pragma once
#include <Arduino.h>
#include <functional>

enum RecordType : uint8_t { REC_SOIL, REC_PLANTING, REC_GROWTH, REC_TYPE_COUNT };

// Returns the value of one form field by name ("" if the phone did not send it).
typedef std::function<String(const char* name)> FieldGetter;

void cropBegin();                                       // after sdBegin(): folder and headers
const char* cropTypeName(RecordType t);                 // "soil", "planting", "growth"

// Each function writes JSON to out, or returns false with a reason in error.
void cropWriteTypesJson(Print& out);                    // the form fields, so the page can build its forms
bool cropWriteUsersJson(Print& out, String& error);
bool cropWriteRecordsJson(RecordType t, long userId, int limit, Print& out, String& error);

bool cropAddUser(const FieldGetter& get, String& error);
bool cropAddRecord(RecordType t, const FieldGetter& get, String& error);
