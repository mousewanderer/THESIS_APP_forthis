// =====================================================================
//  sd_store -- the microSD card and its ONE mutex.
//
//  The SD library is not safe to use from two tasks at once, and three
//  tasks want the card: the keypad loop (dose log), the web server
//  (downloads, crop records) and setup(). Every SD access in this sketch
//  goes through the functions below, and each of them takes the mutex,
//  does one small job (open, read or write, close) and gives it back.
//  So a long download never holds the card for more than one piece.
// =====================================================================
#pragma once
#include <Arduino.h>
#include <functional>

#define SD_LINE_MAX 200            // longest CSV line we read back

bool sdBegin();                    // mounts the card; call once in setup()
bool sdReady();                    // card mounted and the last write worked

// Adds one line to the end of a file. If the file is new, header goes first.
bool sdAppendLine(const char* path, const char* line, const char* header);

// Reads up to len bytes starting at offset. Returns the number of bytes
// read (0 at the end of the file), or -1 if the file is missing or the
// card stayed busy for SD_WAIT_MS.
int sdReadAt(const char* path, uint32_t offset, uint8_t* buf, size_t len);

// File size in bytes, or -1 if the file is missing / the card is busy.
int32_t sdFileSize(const char* path);

// Creates a folder if it does not exist yet.
bool sdMakeDir(const char* path);

// Creates the file with just its header line if it does not exist yet.
bool sdCreateIfMissing(const char* path, const char* header);

// Splits one CSV line in place at the commas (our files never have commas
// inside a value). Returns the number of fields (at most maxFields).
uint8_t csvSplit(char* line, char* fields[], uint8_t maxFields);

// Calls onLine for every line of the file, first line first. Reads 1 KB at
// a time (one mutex turn each). Lines longer than SD_LINE_MAX are skipped.
// Returns false if the file could not be read.
bool sdForEachLine(const char* path, const std::function<void(char* line)>& onLine);
