#include "dose_log.h"
#include "config.h"
#include "sd_store.h"
#include <Preferences.h>
#include <algorithm>

static uint32_t bootNo = 0;
static uint32_t lastNo = 0;          // newest dose number in the file
static uint8_t  lastSeqAtBoot = 0;

void formatDg(char* out, size_t size, int32_t dg) {
  int32_t a = dg < 0 ? -dg : dg;
  snprintf(out, size, "%s%ld.%ld", dg < 0 ? "-" : "", (long)(a / 10), (long)(a % 10));
}

// "248.6" -> 2486, "-1.4" -> -14, "250" -> 2500. False for anything else.
static bool gramsToDg(const char* s, int32_t& dg) {
  bool negative = (*s == '-');
  if (negative) s++;
  if (!isdigit((unsigned char)*s)) return false;
  int32_t whole = 0;
  while (isdigit((unsigned char)*s)) whole = whole * 10 + (*s++ - '0');
  int32_t tenth = 0;
  if (*s == '.') {
    s++;
    if (!isdigit((unsigned char)*s)) return false;
    tenth = *s++ - '0';
  }
  if (*s) return false;
  dg = whole * 10 + tenth;
  if (negative) dg = -dg;
  return true;
}

// Reads one CSV row. False for the header line or a broken row.
static bool parseRow(char* line, DoseRow& r) {
  char* f[10];
  if (csvSplit(line, f, 10) != 9) return false;
  char* end;
  r.no = strtoul(f[0], &end, 10);       if (*end || r.no == 0) return false;
  r.boot = strtoul(f[1], &end, 10);     if (*end) return false;
  r.uptimeS = strtoul(f[2], &end, 10);  if (*end) return false;
  unsigned long seq = strtoul(f[3], &end, 10);
  if (*end || seq > 255) return false;
  r.seq = (uint8_t)seq;
  if (strlen(f[4]) != 1 || f[4][0] < 'A' || f[4][0] > 'C') return false;
  r.recipe = f[4][0];
  return gramsToDg(f[5], r.targetDg) && gramsToDg(f[6], r.actualDg);
}

void doseLogBegin() {
  // Boot counter kept in the ESP32's own flash (NVS), not on the SD card.
  Preferences prefs;
  prefs.begin("agridose", false);
  bootNo = prefs.getUInt("boot", 0) + 1;
  prefs.putUInt("boot", bootNo);
  prefs.end();

  sdCreateIfMissing(DOSE_LOG_PATH, DOSE_LOG_HEADER);

  // Find the newest row so dose numbers and seq numbers carry on after a restart.
  sdForEachLine(DOSE_LOG_PATH, [](char* line) {
    DoseRow r;
    if (parseRow(line, r)) { lastNo = r.no; lastSeqAtBoot = r.seq; }
  });
  Serial.printf("Boot number %lu. Dose log has %lu dose(s).\n", (unsigned long)bootNo, (unsigned long)lastNo);
}

bool doseLogAppend(const DoseResult& d) {
  char target[12], actual[12], error[12], line[96];
  int32_t errorDg = d.actualDg - d.targetDg;
  float errorPct = d.targetDg ? errorDg * 100.0f / d.targetDg : 0.0f;
  formatDg(target, sizeof(target), d.targetDg);
  formatDg(actual, sizeof(actual), d.actualDg);
  formatDg(error, sizeof(error), errorDg);
  snprintf(line, sizeof(line), "%lu,%lu,%lu,%u,%c,%s,%s,%s,%.2f",
           (unsigned long)(lastNo + 1), (unsigned long)bootNo, (unsigned long)(millis() / 1000),
           d.seq, d.recipe, target, actual, error, errorPct);
  if (!sdAppendLine(DOSE_LOG_PATH, line, DOSE_LOG_HEADER)) return false;
  lastNo++;                          // a number is used only once the row is really on the card
  return true;
}

uint8_t  doseLogLastSeq() { return lastSeqAtBoot; }
uint32_t doseLogCount()   { return lastNo; }
uint32_t doseLogBoot()    { return bootNo; }

int doseLogNewest(DoseRow* out, int max) {
  if (max <= 0) return 0;
  int seen = 0;
  // Read the file from the top and keep the last `max` rows in a ring:
  // row number k goes into slot k % max, overwriting older ones.
  bool ok = sdForEachLine(DOSE_LOG_PATH, [&](char* line) {
    DoseRow r;
    if (!parseRow(line, r)) return;
    out[seen % max] = r;
    seen++;
  });
  if (!ok) return -1;
  int n = seen < max ? seen : max;
  if (seen > max) std::rotate(out, out + (seen % max), out + max);  // oldest kept row to the front
  std::reverse(out, out + n);                                       // newest first
  return n;
}
