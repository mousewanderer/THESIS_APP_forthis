// =====================================================================
//  web_server -- the online mode: a look-only dashboard served by the
//  ESP32 itself as a Wi-Fi access point (no internet needed).
//
//  Pages      /  (index.html, app.js, app.css, manifest, icons; from web_assets.h)
//  Live feed  /ws  WebSocket, the live state as JSON, at most every 250 ms
//             and only on a change, plus once a second as a heartbeat
//  API        GET  /api/status                  live state (same JSON as /ws)
//             GET  /api/doses?limit=N           newest dose rows, newest first
//             GET  /api/doses.csv               the whole dose log as a download
//             GET  /api/record-types            crop record fields (to build the forms)
//             GET  /api/users                   farmers
//             POST /api/users                   add a farmer (user_id, name)
//             GET  /api/records/<type>?user_id=N&limit=N   type = soil | planting | growth
//             POST /api/records/<type>          add a record for a user ID
//
//  LOOK-ONLY RULE: web_server.cpp never includes mega_link.h or AgriLink.h.
//  It can read the live state and the SD card, nothing else. No request can
//  send DOSE, TARE or STOP; messages that phones send on /ws are ignored.
// =====================================================================
#pragma once

void webBegin();   // starts the access point, the DNS for the captive portal, and the server
void webLoop();    // call from loop(): pushes live updates, tidies WebSocket clients
