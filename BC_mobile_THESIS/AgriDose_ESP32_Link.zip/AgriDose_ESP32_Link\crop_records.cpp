#include "crop_records.h"
#include "config.h"
#include "sd_store.h"
#include "crop_validate.h"
#include "json_util.h"

#define USERS_PATH   CROP_DIR "/users.csv"
#define USERS_HEADER "user_id,name"
#define USER_ID_MAX  9999
#define USER_NAME_MAX     30
#define MAX_LIST     100           // "View details" shows at most the newest 100

// ---- what each record type contains ----
enum FieldKind : uint8_t { K_INT, K_DECIMAL, K_DATE, K_TEXT, K_YESNO, K_NUMLIST };
static const char* const KIND_NAMES[] = {"int", "decimal", "date", "text", "yesno", "numlist"};

struct FieldSpec {
  const char* name;       // CSV column and form field name
  const char* label;      // shown on the page and in error messages
  FieldKind   kind;
  bool        required;
  long        minV, maxV; // K_INT and K_DECIMAL
  uint8_t     size;       // K_DECIMAL: decimals allowed. K_TEXT / K_NUMLIST: max characters
};

static const FieldSpec SOIL_FIELDS[] = {
  {"plot",              "Plot number",       K_INT,     true,  1, 99,  0},
  {"date_tested",       "Date tested",       K_DATE,    true,  0, 0,   0},
  {"soil_ph",           "Soil pH",           K_DECIMAL, true,  0, 14,  2},
  {"soil_moisture_pct", "Soil moisture (%)", K_DECIMAL, false, 0, 100, 1},
};
static const FieldSpec PLANTING_FIELDS[] = {
  {"plot",          "Plot number",            K_INT,     true,  1, 99, 0},
  {"crop",          "Crop",                   K_TEXT,    true,  0, 0,  30},
  {"variety",       "Variety / seed type",    K_TEXT,    false, 0, 0,  30},
  {"date_planted",  "Date planted",           K_DATE,    true,  0, 0,  0},
  {"used_agridose", "Used AgriDose amendment", K_YESNO,  true,  0, 0,  0},
  {"dose_numbers",  "AgriDose dose numbers",  K_NUMLIST, false, 0, 0,  40},
};
static const FieldSpec GROWTH_FIELDS[] = {
  {"plot",                "Plot number",         K_INT,     true,  1, 99,  0},
  {"date_observed",       "Date observed",       K_DATE,    true,  0, 0,   0},
  {"stage",               "Growth stage",        K_TEXT,    true,  0, 0,   20},
  {"days_after_planting", "Days after planting", K_INT,     false, 0, 365, 0},
  {"height_cm",           "Plant height (cm)",   K_DECIMAL, false, 0, 500, 1},
  {"leaf_count",          "Leaf count",          K_INT,     false, 0, 999, 0},
  {"notes",               "Notes",               K_TEXT,    false, 0, 0,   80},
};

struct RecordSpec {
  const char* type;      // used in the URL: /api/records/<type>
  const char* title;
  const char* path;
  const FieldSpec* fields;
  uint8_t count;
};

#define COUNT_OF(a) (uint8_t)(sizeof(a) / sizeof((a)[0]))
static const RecordSpec SPECS[REC_TYPE_COUNT] = {
  {"soil",     "Soil tests",     CROP_DIR "/soil.csv",      SOIL_FIELDS,     COUNT_OF(SOIL_FIELDS)},
  {"planting", "Plantings",      CROP_DIR "/plantings.csv", PLANTING_FIELDS, COUNT_OF(PLANTING_FIELDS)},
  {"growth",   "Growth records", CROP_DIR "/growth.csv",    GROWTH_FIELDS,   COUNT_OF(GROWTH_FIELDS)},
};

const char* cropTypeName(RecordType t) { return SPECS[t].type; }

// "user_id,plot,date_tested,..."
static void buildHeader(const RecordSpec& s, char* out, size_t size) {
  size_t n = snprintf(out, size, "user_id");
  for (uint8_t i = 0; i < s.count && n < size; i++) n += snprintf(out + n, size - n, ",%s", s.fields[i].name);
}

void cropBegin() {
  if (!sdMakeDir(CROP_DIR)) { Serial.println("Crop records: could not make " CROP_DIR); return; }
  sdCreateIfMissing(USERS_PATH, USERS_HEADER);
  for (uint8_t t = 0; t < REC_TYPE_COUNT; t++) {
    char header[160];
    buildHeader(SPECS[t], header, sizeof(header));
    sdCreateIfMissing(SPECS[t].path, header);
  }
}

// ---- users ----

// Is this user ID in users.csv? readOk is false if the file could not be read.
static bool userExists(long id, bool& readOk) {
  bool found = false;
  readOk = sdForEachLine(USERS_PATH, [&](char* line) {
    if (isdigit((unsigned char)line[0]) && strtol(line, nullptr, 10) == id) found = true;
  });
  return found;
}

bool cropWriteUsersJson(Print& out, String& error) {
  bool first = true;
  out.print('[');
  bool ok = sdForEachLine(USERS_PATH, [&](char* line) {
    char* f[3];
    if (!isdigit((unsigned char)line[0]) || csvSplit(line, f, 3) < 2) return;   // header or broken row
    out.printf("%s{\"id\":%ld,\"name\":", first ? "" : ",", strtol(f[0], nullptr, 10));
    jsonString(out, f[1]);
    out.print('}');
    first = false;
  });
  out.print(']');
  if (!ok) error = "Could not read the SD card";
  return ok;
}

// Note: the web server runs every request one after another in one task,
// so two phones cannot both pass the "already exists" check at once.
bool cropAddUser(const FieldGetter& get, String& error) {
  if (!sdReady()) { error = "SD card problem"; return false; }
  char id[12], name[USER_NAME_MAX + 1];
  if (!cvInt(get("user_id").c_str(), 1, USER_ID_MAX, id, sizeof(id))) {
    error = "User ID must be a whole number from 1 to " + String(USER_ID_MAX);
    return false;
  }
  String rawName = get("name");
  if (cvIsBlank(rawName.c_str()) || !cvText(rawName.c_str(), USER_NAME_MAX, name, sizeof(name))) {
    error = "Name is required (at most " + String(USER_NAME_MAX) + " characters)";
    return false;
  }
  bool readOk;
  if (userExists(atol(id), readOk)) { error = "User ID " + String(id) + " already exists"; return false; }
  if (!readOk) { error = "Could not read the users file"; return false; }

  char line[48];
  snprintf(line, sizeof(line), "%s,%s", id, name);
  if (!sdAppendLine(USERS_PATH, line, USERS_HEADER)) { error = "Could not write to the SD card"; return false; }
  Serial.printf("Crop records: new user %s (%s)\n", id, name);
  return true;
}

// ---- records ----

// Checks one form value against its FieldSpec and writes the cleaned value.
static bool checkField(const FieldSpec& f, const char* raw, char* out, size_t outSize, String& error) {
  if (cvIsBlank(raw)) {
    out[0] = 0;
    if (!f.required) return true;
    error = String(f.label) + " is required";
    return false;
  }
  bool ok = false;
  String range = " from " + String(f.minV) + " to " + String(f.maxV);
  switch (f.kind) {
    case K_INT:
      ok = cvInt(raw, f.minV, f.maxV, out, outSize);
      if (!ok) error = String(f.label) + " must be a whole number" + range;
      break;
    case K_DECIMAL:
      ok = cvDecimal(raw, f.minV, f.maxV, f.size, out, outSize);
      if (!ok) error = String(f.label) + " must be a number" + range + " (at most " + String(f.size) + " decimals)";
      break;
    case K_DATE:
      ok = cvDate(raw, out, outSize);
      if (!ok) error = String(f.label) + " must be a date (YYYY-MM-DD)";
      break;
    case K_TEXT:
      ok = cvText(raw, f.size, out, outSize);
      if (!ok) error = String(f.label) + " must be at most " + String(f.size) + " characters";
      break;
    case K_YESNO:
      ok = cvYesNo(raw, out, outSize);
      if (!ok) error = String(f.label) + " must be yes or no";
      break;
    case K_NUMLIST:
      ok = cvNumberList(raw, f.size, out, outSize);
      if (!ok) error = String(f.label) + " must be numbers separated by spaces";
      break;
  }
  return ok;
}

bool cropAddRecord(RecordType t, const FieldGetter& get, String& error) {
  const RecordSpec& s = SPECS[t];
  if (!sdReady()) { error = "SD card problem"; return false; }

  char id[12];
  if (!cvInt(get("user_id").c_str(), 1, USER_ID_MAX, id, sizeof(id))) { error = "Pick a farmer (user ID) first"; return false; }
  bool readOk;
  if (!userExists(atol(id), readOk)) {
    error = readOk ? "User ID " + String(id) + " is not registered" : String("Could not read the users file");
    return false;
  }

  char line[SD_LINE_MAX + 1];
  size_t n = snprintf(line, sizeof(line), "%s", id);
  for (uint8_t i = 0; i < s.count; i++) {
    char value[96];
    if (!checkField(s.fields[i], get(s.fields[i].name).c_str(), value, sizeof(value), error)) return false;
    n += snprintf(line + n, sizeof(line) - n, ",%s", value);
    if (n >= sizeof(line)) { error = "Record is too long"; return false; }
  }

  char header[160];
  buildHeader(s, header, sizeof(header));
  if (!sdAppendLine(s.path, line, header)) { error = "Could not write to the SD card"; return false; }
  Serial.printf("Crop records: %s saved for user %s\n", s.type, id);
  return true;
}

bool cropWriteRecordsJson(RecordType t, long userId, int limit, Print& out, String& error) {
  const RecordSpec& s = SPECS[t];
  if (limit <= 0 || limit > MAX_LIST) limit = MAX_LIST;

  // Keep the newest `limit` lines of this user in a ring (line k -> slot k % limit).
  typedef char Line[SD_LINE_MAX + 1];
  Line* ring = (Line*)malloc(sizeof(Line) * limit);
  if (ring == nullptr) { error = "The ESP32 is out of memory, try again"; return false; }

  char key[16];
  snprintf(key, sizeof(key), "%ld,", userId);
  size_t keyLen = strlen(key);
  int seen = 0;
  bool ok = sdForEachLine(s.path, [&](char* line) {
    if (strncmp(line, key, keyLen) != 0) return;
    strcpy(ring[seen % limit], line);
    seen++;
  });
  if (!ok) { free(ring); error = "Could not read the SD card"; return false; }

  out.printf("{\"type\":\"%s\",\"user_id\":%ld,\"total\":%d,\"items\":[", s.type, userId, seen);
  int n = seen < limit ? seen : limit;
  for (int k = 0; k < n; k++) {
    char* f[12];
    uint8_t nf = csvSplit(ring[(seen - 1 - k) % limit], f, 12);   // newest first
    out.print(k ? ",{" : "{");
    for (uint8_t i = 0; i < s.count; i++) {
      if (i) out.print(',');
      jsonString(out, s.fields[i].name);
      out.print(':');
      jsonString(out, (uint8_t)(i + 1) < nf ? f[i + 1] : "");
    }
    out.print('}');
  }
  out.print("]}");
  free(ring);
  return true;
}

void cropWriteTypesJson(Print& out) {
  out.print('[');
  for (uint8_t t = 0; t < REC_TYPE_COUNT; t++) {
    const RecordSpec& s = SPECS[t];
    out.printf("%s{\"type\":\"%s\",\"title\":\"%s\",\"fields\":[", t ? "," : "", s.type, s.title);
    for (uint8_t i = 0; i < s.count; i++) {
      const FieldSpec& f = s.fields[i];
      out.printf("%s{\"name\":\"%s\",\"label\":\"%s\",\"kind\":\"%s\",\"required\":%s,\"min\":%ld,\"max\":%ld,\"size\":%u}",
                 i ? "," : "", f.name, f.label, KIND_NAMES[f.kind], f.required ? "true" : "false", f.minV, f.maxV, f.size);
    }
    out.print("]}");
  }
  out.print(']');
}
