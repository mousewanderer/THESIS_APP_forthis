#!/usr/bin/env python3
"""A pretend ESP32 for working on the dashboard page on a laptop.

It serves the files in www/ and answers the same API as web_server.cpp
(/api/..., and the live feed on /ws) with made-up data: a dose runs every
20 s. Edit www/, refresh the browser, no flashing needed. Plain Python,
no extra packages.

This is NOT the firmware: it does not check form input the way the ESP32
does (crop_validate.h). Use it for the look and feel only.

Run:   python AgriDose_ESP32_Link/tools/mock_esp32.py
Open:  http://127.0.0.1:8765/
"""
import base64
import hashlib
import json
import pathlib
import random
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

WWW = pathlib.Path(__file__).resolve().parent.parent / "www"
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8765    # optional: another port
TYPES = {
    "/": ("index.html", "text/html; charset=utf-8"),
    "/app.js": ("app.js", "application/javascript; charset=utf-8"),
    "/app.css": ("app.css", "text/css; charset=utf-8"),
    "/manifest.webmanifest": ("manifest.webmanifest", "application/manifest+json"),
    "/icon-192.png": ("icon-192.png", "image/png"),
    "/icon-512.png": ("icon-512.png", "image/png"),
}

# Same fields as crop_records.cpp (copied by hand; keep them in step).
RECORD_TYPES = [
    {"type": "soil", "title": "Soil tests", "fields": [
        {"name": "plot", "label": "Plot number", "kind": "int", "required": True, "min": 1, "max": 99, "size": 0},
        {"name": "date_tested", "label": "Date tested", "kind": "date", "required": True, "min": 0, "max": 0, "size": 0},
        {"name": "soil_ph", "label": "Soil pH", "kind": "decimal", "required": True, "min": 0, "max": 14, "size": 2},
        {"name": "soil_moisture_pct", "label": "Soil moisture (%)", "kind": "decimal", "required": False, "min": 0, "max": 100, "size": 1}]},
    {"type": "planting", "title": "Plantings", "fields": [
        {"name": "plot", "label": "Plot number", "kind": "int", "required": True, "min": 1, "max": 99, "size": 0},
        {"name": "crop", "label": "Crop", "kind": "text", "required": True, "min": 0, "max": 0, "size": 30},
        {"name": "variety", "label": "Variety / seed type", "kind": "text", "required": False, "min": 0, "max": 0, "size": 30},
        {"name": "date_planted", "label": "Date planted", "kind": "date", "required": True, "min": 0, "max": 0, "size": 0},
        {"name": "used_agridose", "label": "Used AgriDose amendment", "kind": "yesno", "required": True, "min": 0, "max": 0, "size": 0},
        {"name": "dose_numbers", "label": "AgriDose dose numbers", "kind": "numlist", "required": False, "min": 0, "max": 0, "size": 40}]},
    {"type": "growth", "title": "Growth records", "fields": [
        {"name": "plot", "label": "Plot number", "kind": "int", "required": True, "min": 1, "max": 99, "size": 0},
        {"name": "date_observed", "label": "Date observed", "kind": "date", "required": True, "min": 0, "max": 0, "size": 0},
        {"name": "stage", "label": "Growth stage", "kind": "text", "required": True, "min": 0, "max": 0, "size": 20},
        {"name": "days_after_planting", "label": "Days after planting", "kind": "int", "required": False, "min": 0, "max": 365, "size": 0},
        {"name": "height_cm", "label": "Plant height (cm)", "kind": "decimal", "required": False, "min": 0, "max": 500, "size": 1},
        {"name": "leaf_count", "label": "Leaf count", "kind": "int", "required": False, "min": 0, "max": 999, "size": 0},
        {"name": "notes", "label": "Notes", "kind": "text", "required": False, "min": 0, "max": 0, "size": 80}]},
]

lock = threading.Lock()
started = time.time()
state = {"weight_dg": 0, "flag": "I", "done_count": 0, "last": None}
doses = [{"no": n, "boot": 1, "uptime_s": 60 * n, "seq": n, "recipe": "ABC"[n % 3],
          "target_dg": 2500, "actual_dg": 2500 + random.randint(-25, 25)} for n in range(1, 8)]
users = [{"id": 1, "name": "Juan"}]
records = {
    "soil": [{"user_id": "1", "plot": "1", "date_tested": "2026-09-08", "soil_ph": "5.0", "soil_moisture_pct": "30"}],
    "planting": [{"user_id": "1", "plot": "1", "crop": "Pechay", "variety": "Native", "date_planted": "2026-09-08",
                  "used_agridose": "yes", "dose_numbers": "3 4"}],
    "growth": [{"user_id": "1", "plot": "1", "date_observed": "2026-09-20", "stage": "vegetative",
                "days_after_planting": "12", "height_cm": "8.5", "leaf_count": "6", "notes": ""}],
}


def simulate():
    """A dose every 20 s: about 12 s of dosing, then DONE."""
    while True:
        time.sleep(0.2)
        t = (time.time() - started) % 20
        with lock:
            if t < 12:
                state["flag"] = "D"
                state["weight_dg"] = int(t / 12 * 2500)
            elif state["flag"] == "D":
                actual = 2500 + random.randint(-30, 30)
                n = len(doses) + 1
                doses.append({"no": n, "boot": 1, "uptime_s": int(time.time() - started), "seq": n % 255 or 1,
                              "recipe": "ABC"[n % 3], "target_dg": 2500, "actual_dg": actual})
                state.update(flag="I", weight_dg=actual, done_count=state["done_count"] + 1,
                             last={"seq": n, "recipe": "ABC"[n % 3], "target_dg": 2500, "actual_dg": actual})


def status():
    with lock:
        s = {"online": True, "weight_dg": state["weight_dg"], "flag": state["flag"], "last_frame_ms": 120,
             "done_count": state["done_count"], "dose_count": len(doses), "sd_ok": True, "fake_mega": True,
             "boot": 1, "uptime_s": int(time.time() - started), "heap_free": 180000, "heap_min": 150000, "clients": 1}
        if state["last"]:
            s["last"] = state["last"]
    return s


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        pass

    def send_body(self, code, body, ctype="application/json"):
        data = body if isinstance(body, bytes) else body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def send_json(self, obj, code=200):
        self.send_body(code, json.dumps(obj))

    def do_GET(self):
        url = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(url.query).items()}
        if url.path == "/ws":
            return self.websocket()
        if url.path in TYPES:
            name, ctype = TYPES[url.path]
            return self.send_body(200, (WWW / name).read_bytes(), ctype)
        if url.path == "/api/status":
            return self.send_json(status())
        if url.path == "/api/doses":
            limit = max(1, min(200, int(q.get("limit", 20))))
            with lock:
                return self.send_json({"total": len(doses), "items": list(reversed(doses))[:limit]})
        if url.path == "/api/doses.csv":
            lines = ["dose_no,boot,uptime_s,seq,recipe,target_g,actual_g,error_g,error_pct"]
            with lock:
                for d in doses:
                    e = d["actual_dg"] - d["target_dg"]
                    lines.append(f'{d["no"]},{d["boot"]},{d["uptime_s"]},{d["seq"]},{d["recipe"]},'
                                 f'{d["target_dg"] / 10:.1f},{d["actual_dg"] / 10:.1f},{e / 10:.1f},{e * 100 / d["target_dg"]:.2f}')
            return self.send_body(200, "\n".join(lines) + "\n", "text/csv")
        if url.path == "/api/record-types":
            return self.send_json(RECORD_TYPES)
        if url.path == "/api/users":
            return self.send_json(users)
        if url.path.startswith("/api/records/"):
            kind = url.path.rsplit("/", 1)[1]
            mine = [r for r in records.get(kind, []) if r["user_id"] == q.get("user_id")]
            limit = int(q.get("limit", 3)) or 100
            items = [{k: v for k, v in r.items() if k != "user_id"} for r in reversed(mine)][:limit]
            return self.send_json({"type": kind, "user_id": int(q.get("user_id", 0)), "total": len(mine), "items": items})
        self.send_json({"ok": False, "error": "Not found"}, 404)

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        form = {k: v[0] for k, v in parse_qs(self.rfile.read(length).decode()).items()}
        path = urlparse(self.path).path
        if path == "/api/users":
            if not form.get("user_id") or not form.get("name"):
                return self.send_json({"ok": False, "error": "User ID and name are required"}, 400)
            users.append({"id": int(form["user_id"]), "name": form["name"]})
            return self.send_json({"ok": True})
        if path.startswith("/api/records/"):
            kind = path.rsplit("/", 1)[1]
            spec = next((t for t in RECORD_TYPES if t["type"] == kind), None)
            if spec is None:
                return self.send_json({"ok": False, "error": "Not found"}, 404)
            for f in spec["fields"]:
                if f["required"] and not form.get(f["name"]):
                    return self.send_json({"ok": False, "error": f'{f["label"]} is required'}, 400)
            records[kind].append({"user_id": form.get("user_id", "")} | {f["name"]: form.get(f["name"], "") for f in spec["fields"]})
            return self.send_json({"ok": True})
        self.send_json({"ok": False, "error": "Not found"}, 404)

    def websocket(self):
        """Minimal WebSocket: handshake, then a status message twice a second."""
        key = self.headers.get("Sec-WebSocket-Key", "")
        accept = base64.b64encode(hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode()).digest()).decode()
        self.send_response(101)
        self.send_header("Upgrade", "websocket")
        self.send_header("Connection", "Upgrade")
        self.send_header("Sec-WebSocket-Accept", accept)
        self.end_headers()
        self.close_connection = True
        try:
            while True:
                data = json.dumps(status()).encode()
                header = bytes([0x81, len(data)]) if len(data) < 126 else bytes([0x81, 126]) + len(data).to_bytes(2, "big")
                self.wfile.write(header + data)
                self.wfile.flush()
                time.sleep(0.5)
        except OSError:
            pass                                   # the browser closed the page


if __name__ == "__main__":
    threading.Thread(target=simulate, daemon=True).start()
    print(f"Mock ESP32 on http://127.0.0.1:{PORT}/  (Ctrl+C to stop)")
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
