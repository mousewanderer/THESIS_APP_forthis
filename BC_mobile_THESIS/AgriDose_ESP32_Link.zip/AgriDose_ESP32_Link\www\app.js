'use strict';
// AgriDose dashboard. LOOK-ONLY for the machine: this page only reads the
// live feed (/ws) and the history (/api/...). The only things it can save
// are farmers and crop records on the SD card. No frameworks, no internet:
// every file comes from the ESP32.

const $ = (sel, root = document) => root.querySelector(sel);

// Makes an element: el('td', {text: '5'}), el('div', {class: 'x'}, child, ...)
function el(tag, attrs, ...children) {
  const e = document.createElement(tag);
  for (const k in attrs || {}) {
    if (k === 'class') e.className = attrs[k];
    else if (k === 'text') e.textContent = attrs[k];
    else e.setAttribute(k, attrs[k]);
  }
  e.append(...children);
  return e;
}

// Browser storage may be blocked (private tab); the page must work without it.
const store = {
  get(k) { try { return localStorage.getItem(k); } catch (_) { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (_) {} },
};

// ---- number formatting (masses arrive in decigrams, 1 g = 10 dg) ----
function g1(dg) {                       // 2486 -> "248.6", exact, no rounding
  const sign = dg < 0 ? '-' : '';
  dg = Math.abs(dg);
  return sign + Math.floor(dg / 10) + '.' + (dg % 10);
}
function signedG(dg) { return (dg > 0 ? '+' : '') + g1(dg); }
function pctNumber(errDg, targetDg) {   // "+0.60"
  if (!targetDg) return '-';
  const p = (errDg * 100) / targetDg;
  return (p > 0 ? '+' : '') + p.toFixed(2);
}
function pct(errDg, targetDg) { return pctNumber(errDg, targetDg) + ' %'; }
function today() {                      // the phone's date, YYYY-MM-DD
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

// ---- talking to the ESP32 ----
async function getJson(url, opts) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 8000);
  try {
    const res = await fetch(url, Object.assign({ cache: 'no-store', signal: ctl.signal }, opts));
    let data = null;
    try { data = await res.json(); } catch (_) {}
    if (!res.ok) throw new Error((data && data.error) || 'HTTP ' + res.status);
    return data;
  } catch (e) {
    if (e.name === 'AbortError') throw new Error('no answer from the ESP32');
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

// ================================================================ tabs ==
function showTab(name) {
  document.querySelectorAll('.tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === name));
  document.querySelectorAll('.tab').forEach((s) => { s.hidden = s.id !== 'tab-' + name; });
  store.set('tab', name);
  if (name === 'doses') loadDoses();
  if (name === 'crops') loadCrops();
}
document.querySelectorAll('.tabs button').forEach((b) => b.addEventListener('click', () => showTab(b.dataset.tab)));

// ================================================================ live ==
const STATE_WORDS = { I: 'Idle: ready', D: 'Dosing...', F: 'Fault: check the machine', '?': 'Waiting for the Mega' };
let live = null;
let lastDoseCount = null;

function renderLast(d) {
  $('#last-none').hidden = true;
  $('#last').hidden = false;
  const err = d.actual_dg - d.target_dg;
  $('#l-recipe').textContent = 'Recipe ' + d.recipe + (d.no ? ' (dose no. ' + d.no + ')' : '');
  $('#l-target').textContent = g1(d.target_dg) + ' g';
  $('#l-actual').textContent = g1(d.actual_dg) + ' g';
  $('#l-error').textContent = signedG(err) + ' g  (' + pct(err, d.target_dg) + ')';
}

function renderLive(s) {
  live = s;
  const pill = $('#link');
  pill.textContent = s.online ? 'Mega online' : 'Mega offline';
  pill.className = 'pill ' + (s.online ? 'ok' : 'bad');

  $('#weight').textContent = s.flag === '?' ? '--.-' : g1(s.weight_dg);
  $('#weight-card').classList.toggle('stale', !s.online);
  const state = $('#state');
  state.textContent = s.online ? STATE_WORDS[s.flag] || s.flag : 'Mega offline: no data for 2 s';
  state.className = 'state ' + (!s.online || s.flag === 'F' ? 'bad' : s.flag === 'D' ? 'busy' : 'ok');

  $('#fake').hidden = !s.fake_mega;
  $('#sd-warn').hidden = s.sd_ok;
  if (s.last) renderLast(s.last);
  if (lastDoseCount !== null && s.dose_count !== lastDoseCount) loadDoses();   // a new row was logged
  lastDoseCount = s.dose_count;

  $('#sys').textContent = 'ESP32 boot ' + s.boot + ', up ' + Math.floor(s.uptime_s / 60) + ' min, ' +
    Math.round(s.heap_free / 1024) + ' KB free (lowest ' + Math.round(s.heap_min / 1024) + ' KB), ' +
    s.clients + ' phone(s) on the live feed';
}

// ---- WebSocket with automatic reconnect ----
// The ESP32 sends at least once a second. If nothing arrives for 5 s (the
// phone slept, the Wi-Fi dropped), the socket is thrown away and a new one
// is opened. Waking the phone or coming back online reconnects at once.
let ws = null;
let lastMsgAt = 0;
let retryMs = 1000;
let retryTimer = null;
let downSince = Date.now();

function setConnected(ok) {
  if (ok) downSince = 0;
  else if (!downSince) downSince = Date.now();
}

function connect() {
  clearTimeout(retryTimer);
  if (ws) return;
  const sock = new WebSocket('ws://' + location.host + '/ws');
  ws = sock;
  sock.onopen = () => { retryMs = 1000; lastMsgAt = Date.now(); setConnected(true); };
  sock.onmessage = (e) => {
    lastMsgAt = Date.now();
    try { renderLive(JSON.parse(e.data)); } catch (_) {}
  };
  sock.onclose = () => {
    if (ws !== sock) return;           // an old socket we already replaced
    ws = null;
    setConnected(false);
    retryTimer = setTimeout(connect, retryMs);
    retryMs = Math.min(retryMs * 2, 10000);
  };
  sock.onerror = () => { try { sock.close(); } catch (_) {} };
}

function reconnectNow() {
  const old = ws;
  ws = null;
  if (old) {
    old.onclose = old.onmessage = old.onerror = null;
    try { old.close(); } catch (_) {}
  }
  setConnected(false);
  retryMs = 1000;
  connect();
}

setInterval(() => {
  if (ws && ws.readyState === WebSocket.OPEN && Date.now() - lastMsgAt > 5000) reconnectNow();   // silent socket
  $('#banner').hidden = !(downSince && Date.now() - downSince > 2000);
  if (downSince && Date.now() - downSince > 2000) {
    const pill = $('#link');
    pill.textContent = 'No Wi-Fi link';
    pill.className = 'pill bad';
  }
}, 1000);
document.addEventListener('visibilitychange', () => {
  if (!document.hidden && (!ws || Date.now() - lastMsgAt > 3000)) reconnectNow();
});
window.addEventListener('online', reconnectNow);
window.addEventListener('pageshow', (e) => { if (e.persisted) reconnectNow(); });

// =============================================================== doses ==
let doseLimit = 20;
let dosesLoading = false;

async function loadDoses() {
  if (dosesLoading) return;
  dosesLoading = true;
  try {
    const data = await getJson('/api/doses?limit=' + doseLimit);
    const body = $('#dose-rows');
    body.textContent = '';
    for (const d of data.items) {
      const err = d.actual_dg - d.target_dg;
      body.append(el('tr', {},
        el('td', { text: d.no }), el('td', { text: d.recipe }),
        el('td', { text: g1(d.target_dg) }), el('td', { text: g1(d.actual_dg) }),
        el('td', { text: signedG(err) }), el('td', { text: pctNumber(err, d.target_dg) })));
    }
    $('#dose-count').textContent = data.items.length
      ? 'Newest first. Showing ' + data.items.length + ' of ' + data.total + '.'
      : 'No doses logged yet.';
    $('#dose-more').hidden = data.items.length >= data.total || doseLimit >= 200;
    if (data.items.length && !(live && live.last)) renderLast(data.items[0]);
  } catch (err) {
    $('#dose-count').textContent = 'Could not load the dose history: ' + err.message;
  } finally {
    dosesLoading = false;
  }
}
$('#dose-more').addEventListener('click', () => { doseLimit = 200; loadDoses(); });

// =============================================================== crops ==
let types = null;                       // record types and their fields, from the ESP32
let currentUser = '';
const showAll = {};                     // type -> true while "View details" is open

async function loadCrops() {
  try {
    if (!types) {
      types = await getJson('/api/record-types');
      buildRecordCards();
    }
    await loadUsers();
    $('#crop-msg').textContent = '';
  } catch (err) {
    $('#crop-msg').textContent = 'Could not load crop records: ' + err.message;
    $('#crop-msg').className = 'msg bad';
  }
}

async function loadUsers(selectId) {
  const users = await getJson('/api/users');
  const sel = $('#user');
  sel.textContent = '';
  sel.append(el('option', { value: '', text: users.length ? 'Choose a farmer...' : 'No farmers yet: add one below' }));
  for (const u of users) sel.append(el('option', { value: u.id, text: u.id + ' - ' + u.name }));
  const want = String(selectId || store.get('user') || '');
  if (users.some((u) => String(u.id) === want)) sel.value = want;
  else if (users.length === 1) sel.value = String(users[0].id);   // only one farmer: pick them
  onUserChange();
}

function onUserChange() {
  currentUser = $('#user').value;
  store.set('user', currentUser);
  $('#records').hidden = !currentUser;
  if (currentUser) types.forEach((t) => loadRecords(t.type));
}
$('#user').addEventListener('change', onUserChange);

// One record as two lines: "2026-09-08 - Plot 1", then the other filled-in fields.
function recordItem(spec, item) {
  const dateField = spec.fields.find((f) => f.kind === 'date');
  const head = (dateField ? item[dateField.name] : '') + ' - Plot ' + item.plot;
  const rest = spec.fields
    .filter((f) => f !== dateField && f.name !== 'plot' && item[f.name] !== '')
    .map((f) => f.label + ': ' + item[f.name]);
  return el('div', { class: 'item' }, el('div', { class: 'item-head', text: head }), el('div', { text: rest.join(' | ') }));
}

async function loadRecords(type) {
  const card = $('.rec[data-type="' + type + '"]');
  const list = $('.list', card);
  const more = $('.more', card);
  const spec = types.find((t) => t.type === type);
  list.textContent = 'Loading...';
  try {
    const limit = showAll[type] ? 100 : 3;
    const data = await getJson('/api/records/' + type + '?user_id=' + encodeURIComponent(currentUser) + '&limit=' + limit);
    list.textContent = '';
    if (!data.items.length) list.append(el('p', { class: 'muted', text: 'Nothing recorded yet.' }));
    for (const item of data.items) list.append(recordItem(spec, item));
    if (showAll[type] && data.total > data.items.length) {
      list.append(el('p', { class: 'muted', text: 'Showing the newest ' + data.items.length + ' of ' + data.total + '.' }));
    }
    more.hidden = data.total <= 3;
    more.textContent = showAll[type] ? 'Show the latest 3' : 'View details (all ' + data.total + ')';
  } catch (err) {
    list.textContent = 'Could not load: ' + err.message;
  }
}

// Builds an input from a field description sent by the ESP32 (crop_records.cpp).
function fieldInput(f) {
  let input;
  if (f.kind === 'yesno') {
    input = el('select', { name: f.name },
      el('option', { value: '', text: 'Choose...' }), el('option', { value: 'yes', text: 'Yes' }), el('option', { value: 'no', text: 'No' }));
  } else {
    input = el('input', { name: f.name });
    if (f.kind === 'int' || f.kind === 'decimal') {
      input.type = 'number';
      input.min = f.min;
      input.max = f.max;
      input.step = f.kind === 'int' ? '1' : String(Math.pow(10, -f.size));
      input.inputMode = f.kind === 'int' ? 'numeric' : 'decimal';
    } else if (f.kind === 'date') {
      input.type = 'date';
      input.defaultValue = today();
    } else if (f.kind === 'numlist') {
      input.inputMode = 'numeric';
      input.maxLength = f.size;
      input.placeholder = 'dose numbers, e.g. 12 13';
    } else {
      input.maxLength = f.size;
      if (f.name === 'stage') input.setAttribute('list', 'stages');
    }
  }
  input.required = f.required;
  return el('label', {}, f.label + (f.required ? '' : ' (optional)'), input);
}

function buildRecordCards() {
  const host = $('#records');
  host.textContent = '';
  for (const t of types) {
    const form = el('form', { class: 'form' });
    t.fields.forEach((f) => form.append(fieldInput(f)));
    form.append(el('button', { type: 'submit', text: 'Save' }), el('p', { class: 'msg', role: 'status' }));
    form.addEventListener('submit', (ev) => { ev.preventDefault(); saveRecord(t.type, form); });

    const more = el('button', { type: 'button', class: 'more link', text: 'View details' });
    more.addEventListener('click', () => { showAll[t.type] = !showAll[t.type]; loadRecords(t.type); });

    host.append(el('section', { class: 'card rec', 'data-type': t.type },
      el('h2', { text: t.title }), el('div', { class: 'list' }), more,
      el('details', {}, el('summary', { text: 'Add to ' + t.title.toLowerCase() }), form)));
  }
}

async function submitForm(form, url, extra) {
  const msg = $('.msg', form);
  const button = $('button', form);
  const body = new URLSearchParams(new FormData(form));
  for (const k in extra || {}) body.set(k, extra[k]);
  button.disabled = true;
  msg.className = 'msg';
  msg.textContent = 'Saving...';
  try {
    await getJson(url, { method: 'POST', body });
    msg.textContent = 'Saved.';
    msg.className = 'msg ok';
    form.reset();
    return true;
  } catch (err) {
    msg.textContent = err.message;      // the ESP32's own reason, e.g. "Soil pH must be a number from 0 to 14"
    msg.className = 'msg bad';
    return false;
  } finally {
    button.disabled = false;
  }
}

async function saveRecord(type, form) {
  if (!currentUser) return;
  if (await submitForm(form, '/api/records/' + type, { user_id: currentUser })) loadRecords(type);
}

$('#f-user').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const form = ev.target;
  const id = form.elements.user_id.value;
  if (await submitForm(form, '/api/users')) loadUsers(id);
});

// =============================================================== start ==
// A tab can also be opened by address: http://192.168.4.1/#doses
const TABS = ['live', 'doses', 'crops'];
function tabFromHash() { const t = location.hash.slice(1); return TABS.includes(t) ? t : null; }
window.addEventListener('hashchange', () => { if (tabFromHash()) showTab(tabFromHash()); });

connect();
showTab(tabFromHash() || (TABS.includes(store.get('tab')) ? store.get('tab') : 'live'));
